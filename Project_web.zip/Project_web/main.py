import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
import random
import requests
import csv
from data import db_session
from data.reminders import Reminder
import datetime as dt
import schedule
import threading

geocoder_api_server = "http://geocode-maps.yandex.ru/1.x/"  # Константы
TIME_PERIOD = 15 * 60


def town_exists(object, name):  # Проверка существования города
    obj_coords = object['GeoObject']['Point']['pos']
    obj_coords = ', '.join(obj_coords.split())
    geocoder_params = {
        "apikey": "40d1649f-0493-4b70-98ba-98533de7710b",
        "geocode": obj_coords,
        "kind": "locality",
        "format": "json"}
    response = requests.get(geocoder_api_server, params=geocoder_params)
    json_response = response.json()
    new_object = json_response['response']['GeoObjectCollection']['featureMember'][0]['GeoObject']
    new_object_name = new_object['name'].lower()
    new_object_kind = new_object['metaDataProperty']['GeocoderMetaData']['kind']
    if new_object_name == name and new_object_kind == 'locality':
        return True
    return False


def check_reminders(vk):  # Поиск ближайших напоминаний
    db_sess = db_session.create_session()
    # print(schedule.get_jobs())
    for reminder in db_sess.query(Reminder).all():
        now = dt.datetime.now()
        if dt.timedelta(seconds=0) < reminder.show_date - now <= dt.timedelta(seconds=TIME_PERIOD):
            hour = str(reminder.show_date.hour).rjust(2, '0')
            minute = str(reminder.show_date.minute).rjust(2, '0')
            second = str(reminder.show_date.second).rjust(2, '0')
            time = f'{hour}:{minute}:{second}'
            schedule.every().day.at(time).do(send_reminder, vk=vk, user_id=reminder.user_id,
                                             name=reminder.name, text=reminder.text)
            db_sess.delete(reminder)
        elif reminder.show_date < now:
            db_sess.delete(reminder)
    db_sess.commit()


def send_reminder(vk, user_id, name, text):  # Отправка напоминаний
    message = f'{name}\n{text}'
    vk.messages.send(user_id=user_id, message=message,
                     random_id=random.randint(0, 2 ** 64))
    return schedule.CancelJob


class MyThread(threading.Thread):  # Второй поток для постоянной проверки напоминаний
    def __init__(self, vk):
        threading.Thread.__init__(self)
        self.thread_name = 'thread_2'
        self.thread_ID = 2
        self.vk = vk

    def run(self):
        schedule.every(2).seconds.do(check_reminders, vk=self.vk)
        while True:
            schedule.run_pending()


def main():
    db_session.global_init("db/reminders.db")  # Подключение к базе данных
    vk_session = vk_api.VkApi(
        token='043935bf9ba099e486db105419e280ba60213f85ea6f9063d6be266ae5a0b2713025ea8816b954215e57d'
    )
    vk = vk_session.get_api()
    longpoll = VkBotLongPoll(vk_session, 204056620)  # Подключение к сообществу
    users = {}
    used = {}
    last_city = {}
    thread_2 = MyThread(vk)
    thread_2.start()
    with open('static/cities.csv', encoding='utf8') as file:  # Загрузка списка городов
        reader = csv.DictReader(file, delimiter=';', quotechar='"')
        CITIES = {i['first_letter']: set(i['cities'].split(',')) for i in reader}
    for event in longpoll.listen():
        if event.type == VkBotEventType.MESSAGE_NEW:  # Обработка новых сообщений
            user_id = event.obj.message['from_id']
            if user_id not in users.keys():  # Сохранение нового пользователя и выбор действий
                users[user_id] = 0
                response = vk.users.get(user_id=user_id, fields="first_name")
                first_name = response[0]['first_name']
                message = f'Здравствуйте, {first_name}, что вы хотите?'
                with open('static/keyboards/start_menu.json', encoding='utf8') as file:
                    keyboard = file.read()
                vk.messages.send(user_id=user_id, message=message, keyboard=keyboard,
                                 random_id=random.randint(0, 2 ** 64))
            elif users[user_id] == 0:  # Начало выполнения функций в зависимости от выбора пользователя
                text = event.obj.message['text'].lower()
                if text == 'поиграть':
                    users[user_id] = 1
                    with open('static/keyboards/games.json', encoding='utf8') as file:
                        keyboard = file.read()
                    message = 'Выберите игру'
                    vk.messages.send(user_id=user_id, message=message, keyboard=keyboard,
                                     random_id=random.randint(0, 2 ** 64))
                elif text == 'завершить сеанс':
                    message = 'До свидания'
                    vk.messages.send(user_id=user_id, message=message,
                                     random_id=random.randint(0, 2 ** 64))
                    users.pop(user_id)
                elif text == 'редактировать уведомления':
                    users[user_id] = 5
                    db_sess = db_session.create_session()
                    user_reminders = []
                    for reminder in db_sess.query(Reminder).filter(Reminder.user_id == user_id).all():
                        user_reminders.append(
                            ' '.join([str(reminder.id), reminder.name, reminder.text,
                                      str(reminder.show_date)]))
                    message = 'Ваши напоминания:\n' + '\n'.join(user_reminders)
                    with open('static/keyboards/reminders.json', encoding='utf8') as file:
                        keyboard = file.read()
                    vk.messages.send(user_id=user_id, message=message, keyboard=keyboard,
                                     random_id=random.randint(0, 2 ** 64))
                else:
                    message = 'Извините, данная функция недоступна'
                    with open('static/keyboards/start_menu.json', encoding='utf8') as file:
                        keyboard = file.read()
                    vk.messages.send(user_id=user_id, message=message, keyboard=keyboard,
                                     random_id=random.randint(0, 2 ** 64))
            elif users[user_id] == 1:  # Начало игры в "Города"
                text = event.obj.message['text'].lower()
                if text == 'города':
                    message = 'Отлично, вы начинаете'
                    users[user_id] = 2
                    used[user_id] = set()
                    vk.messages.send(user_id=user_id, message=message,
                                     random_id=random.randint(0, 2 ** 64))
            elif users[user_id] == 2:  # Игра в "Города"
                text = event.obj.message['text'].lower()
                last_letter = ''
                if user_id in last_city.keys():
                    if last_city[user_id][-1] not in ['ь', 'ы', 'ъ']:
                        last_letter = last_city[user_id][-1]
                    else:
                        last_letter = last_city[user_id][-2]
                if last_letter and last_letter != text[0]:
                    message = f'Ты называешь город на букву "{last_letter}"'
                    vk.messages.send(user_id=user_id, message=message,
                                     random_id=random.randint(0, 2 ** 64))
                else:
                    if text in used[user_id]:
                        message = 'Этот городу уже был, назови другой'
                        vk.messages.send(user_id=user_id, message=message,
                                         random_id=random.randint(0, 2 ** 64))
                    else:
                        used[user_id].add(text)
                        continue_game = True
                        last_letter = text[0]
                        if last_letter in ['ь', 'ы', 'ъ']:
                            last_letter = text[-1]
                        if text not in CITIES[last_letter]:
                            geocoder_params = {
                                "apikey": "40d1649f-0493-4b70-98ba-98533de7710b",
                                "geocode": text,
                                "format": "json"}
                            response = requests.get(geocoder_api_server, params=geocoder_params)
                            json_response = response.json()["response"]["GeoObjectCollection"]["featureMember"]
                            if not json_response:
                                continue_game = False
                            elif town_exists(json_response[0], text):
                                continue_game = True
                                CITIES[text[0]].add(text)
                            else:
                                continue_game = False

                        if continue_game:
                            message = 'Я сдаюсь, ты выиграл\nОтправьте мне любое сообщение, чтобы продолжить'
                            users[user_id] = 3
                            for city in CITIES[text[-1]]:
                                if city not in used[user_id] and city:
                                    message = city
                                    users[user_id] = 2
                                    used[user_id].add(city)
                                    last_city[user_id] = city
                        else:
                            message = 'Я не знаю такого города, назови другой'
                        vk.messages.send(user_id=user_id, message=message,
                                         random_id=random.randint(0, 2 ** 64))
            elif users[user_id] == 3:  # Конец игры в "Города"
                message = 'Желаете сыграть ещё раз?'
                with open('static/keyboards/replay.json', encoding='utf8') as file:
                    keyboard = file.read()
                vk.messages.send(user_id=user_id, message=message, keyboard=keyboard,
                                 random_id=random.randint(0, 2 ** 64))
                users[user_id] = 4
            elif users[user_id] == 4:  # Сохранение новых городов и перезапуск или конец игры в "Города"
                text = event.obj.message['text'].lower()
                file_to_save = [{'first_letter': i, 'cities': ','.join(CITIES[i]).lstrip(',')}
                                for i in CITIES.keys()]
                with open('cities.csv', 'w', newline='') as file:
                    writer = csv.DictWriter(
                        file, fieldnames=list(file_to_save[0].keys()),
                        delimiter=';', quoting=csv.QUOTE_NONNUMERIC)
                    writer.writeheader()
                    for d in file_to_save:
                        writer.writerow(d)
                if text == 'да':
                    last_city.pop(user_id)
                    message = 'Отлично, Вы начинаете'
                    users[user_id] = 2
                    used[user_id].clear()
                    vk.messages.send(user_id=user_id, message=message,
                                     random_id=random.randint(0, 2 ** 64))
                elif text == 'нет':
                    message = 'Что вы хотите?'
                    users[user_id] = 1
                    with open('static/keyboards/start_menu.json', encoding='utf8') as file:
                        keyboard = file.read()
                    vk.messages.send(user_id=user_id, message=message, keyboard=keyboard,
                                     random_id=random.randint(0, 2 ** 64))
                else:
                    message = 'Извините, я Вас не понимаю'
                    vk.messages.send(user_id=user_id, message=message,
                                     random_id=random.randint(0, 2 ** 64))
            elif users[user_id] == 5:  # Меню действий с напоминаниями
                text = event.obj.message['text'].lower()
                if text == 'добавить напоминание':
                    users[user_id] = 6
                    message = 'Введите информацию о напоминание в следующем формате:\n' \
                              'название_дата показа (yyyy-mm-dd-hh-mm-ss)_текст напоминания'
                    vk.messages.send(user_id=user_id, message=message,
                                     random_id=random.randint(0, 2 ** 64))
                elif text == 'удалить напоминание':
                    users[user_id] = 7
                    message = 'Введите id напоминания, которое хотите удалить'
                    vk.messages.send(user_id=user_id, message=message,
                                     random_id=random.randint(0, 2 ** 64))
                elif text == 'отмена':
                    message = 'Что вы хотите?'
                    users[user_id] = 0
                    with open('static/keyboards/start_menu.json', encoding='utf8') as file:
                        keyboard = file.read()
                    vk.messages.send(user_id=user_id, message=message, keyboard=keyboard,
                                     random_id=random.randint(0, 2 ** 64))
                else:
                    message = 'Извините, я не знаю такой команды'
                    vk.messages.send(user_id=user_id, message=message,
                                     random_id=random.randint(0, 2 ** 64))
            elif users[user_id] == 6:  # Добавление нового напоминания
                text = event.obj.message['text'].lower().split('_')
                if len(text) > 3:
                    text = text[0] + text[1] + ['_'.join(text[2:])]
                if len(text) < 3:
                    message = 'Неверный формат, попробуйте ещё раз'
                    vk.messages.send(user_id=user_id, message=message,
                                     random_id=random.randint(0, 2 ** 64))
                else:
                    correct_date = True
                    try:
                        date = dt.datetime(*[int(i) for i in text[1].split('-')])
                    except Exception as error:
                        message = 'Неверный формат, попробуйте ещё раз'
                        vk.messages.send(user_id=user_id, message=message,
                                         random_id=random.randint(0, 2 ** 64))
                        correct_date = False
                    if correct_date:
                        if date <= dt.datetime.now():
                            message = 'Извините, функция отправки сообщений в прошлое недоступна.'
                            vk.messages.send(user_id=user_id, message=message,
                                             random_id=random.randint(0, 2 ** 64))
                        else:
                            db_sess = db_session.create_session()
                            new_reminder = Reminder()
                            new_reminder.user_id = user_id
                            new_reminder.name = text[0]
                            new_reminder.text = text[2]
                            new_reminder.show_date = date
                            db_sess.add(new_reminder)
                            db_sess.commit()
                            message = 'Новое напоминание успешно добавлено'
                            vk.messages.send(user_id=user_id, message=message,
                                             random_id=random.randint(0, 2 ** 64))
                            users[user_id] = 5
                            db_sess = db_session.create_session()
                            user_reminders = []
                            for reminder in db_sess.query(Reminder).filter(Reminder.user_id
                                                                           == user_id).all():
                                user_reminders.append(
                                    ' '.join([str(reminder.id), reminder.name, reminder.text,
                                              str(reminder.show_date)]))
                            message = 'Ваши напоминания:\n' + '\n'.join(user_reminders)
                            with open('static/keyboards/reminders.json', encoding='utf8') as file:
                                keyboard = file.read()
                            vk.messages.send(user_id=user_id, message=message, keyboard=keyboard,
                                             random_id=random.randint(0, 2 ** 64))
            elif users[user_id] == 7:  # Удаление напоминания
                text = event.obj.message['text'].lower()
                if not text.isdigit():
                    message = 'Введёный id некорректен'
                    vk.messages.send(user_id=user_id, message=message,
                                     random_id=random.randint(0, 2 ** 64))
                else:
                    reminder_id = int(text)
                    db_sess = db_session.create_session()
                    item_to_delete = db_sess.query(Reminder).filter(Reminder.id ==
                                                                    reminder_id).first()
                    if item_to_delete is not None:
                        db_sess.delete(item_to_delete)
                        message = 'Напоминание успешно удалено'
                        vk.messages.send(user_id=user_id, message=message, keyboard=keyboard,
                                         random_id=random.randint(0, 2 ** 64))
                        users[user_id] = 5
                        db_sess.commit()
                        db_sess = db_session.create_session()
                        user_reminders = []
                        for reminder in db_sess.query(Reminder).filter(Reminder.user_id ==
                                                                       user_id).all():
                            user_reminders.append(
                                ' '.join([str(reminder.id), reminder.name, reminder.text,
                                          str(reminder.show_date)]))
                        message = 'Ваши напоминания:\n' + '\n'.join(user_reminders)
                        with open('static/keyboards/reminders.json', encoding='utf8') as file:
                            keyboard = file.read()
                        vk.messages.send(user_id=user_id, message=message, keyboard=keyboard,
                                         random_id=random.randint(0, 2 ** 64))
                    else:
                        message = 'У Вас нет доступа к введённому id'
                        vk.messages.send(user_id=user_id, message=message,
                                         random_id=random.randint(0, 2 ** 64))


if __name__ == '__main__':  # Вызов главной функции
    main()
