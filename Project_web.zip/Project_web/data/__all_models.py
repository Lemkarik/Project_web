from . import reminders
# Добавление класса напоминаний в базу данных
