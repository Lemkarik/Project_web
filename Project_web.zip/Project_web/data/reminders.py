import sqlalchemy
from .db_session import SqlAlchemyBase


class Reminder(SqlAlchemyBase):  # Класс напоминания
    __tablename__ = 'reminders'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    user_id = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    text = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    show_date = sqlalchemy.Column(sqlalchemy.DateTime, nullable=False)